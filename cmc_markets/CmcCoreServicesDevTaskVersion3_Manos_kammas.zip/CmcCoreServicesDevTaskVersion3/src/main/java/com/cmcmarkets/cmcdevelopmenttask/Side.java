package com.cmcmarkets.cmcdevelopmenttask;

public enum Side {
    BUY,
    SELL;
}
